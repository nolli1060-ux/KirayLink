"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Mail, Lock, ShieldAlert, ArrowRight, UserCheck } from "lucide-react";
import { signInAction } from "@/lib/auth";
import Button from "@/components/ui/Button";
import Input from "@/components/ui/Input";

const demoAccounts = [
  {
    role: "Tenant Demo",
    email: "tenant@kiraylink.com",
    password: "TenantPass123!",
    description: "Sara Hailu — Tenant Portal",
  },
  {
    role: "Landlord Demo",
    email: "landlord@kiraylink.com",
    password: "LandlordPass123!",
    description: "Dawit Bekele — Landlord Portal",
  },
  {
    role: "Admin Demo",
    email: "admin@kiraylink.com",
    password: "AdminPass123!",
    description: "KirayLink Admin Desk",
  },
];

export default function SignInForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const returnUrl = searchParams.get("redirect") || "";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // Quick fill demo credentials
  const fillDemoAccount = (demoEmail: string, demoPass: string) => {
    setEmail(demoEmail);
    setPassword(demoPass);
    setErrorMessage("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");

    if (!email.trim() || !password) {
      setErrorMessage("Please enter both your email and password.");
      return;
    }

    setIsLoading(true);

    try {
      const formData = new FormData();
      formData.set("email", email);
      formData.set("password", password);
      if (returnUrl) formData.set("returnUrl", returnUrl);

      const result = await signInAction(null, formData);

      if (!result.success) {
        setErrorMessage(
          result.error || "Authentication failed. Please verify credentials."
        );
        setIsLoading(false);
      } else if (result.redirectUrl) {
        router.push(result.redirectUrl);
        router.refresh();
      }
    } catch {
      setErrorMessage("An unexpected network error occurred. Please try again.");
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Demo Credentials Quick-Fill (Essential for walkthroughs & evaluators) */}
      <div className="bg-[#F7F3EC] border border-[#C5A880]/40 rounded-lg p-4 space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#8C6E43]">
          <UserCheck className="w-4 h-4 text-[#C5A880]" aria-hidden="true" />
          <span>Capstone Evaluator Quick Sign-In</span>
        </div>
        <p className="text-xs text-[#5B677A]">
          Click any role below to pre-fill credentials for your testing walkthrough:
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {demoAccounts.map((acc) => (
            <button
              key={acc.role}
              type="button"
              onClick={() => fillDemoAccount(acc.email, acc.password)}
              className="text-left p-2.5 rounded bg-white border border-[#E6E0D5] hover:border-[#C5A880] transition-colors cursor-pointer text-xs space-y-0.5"
            >
              <div className="font-semibold text-[#0F172A]">{acc.role}</div>
              <div className="text-[11px] text-[#5B677A] truncate">
                {acc.email}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Sign-In Form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        {errorMessage && (
          <div
            role="alert"
            className="p-3.5 rounded bg-[#FDF2F2] border border-[#9E2A2B]/30 flex items-start gap-2.5 text-xs text-[#9E2A2B]"
          >
            <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
            <span>{errorMessage}</span>
          </div>
        )}

        <Input
          label="Email Address"
          type="email"
          name="email"
          autoComplete="email"
          placeholder="e.g. resident@kiraylink.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          icon={<Mail className="w-4 h-4" aria-hidden="true" />}
          disabled={isLoading}
        />

        <Input
          label="Password"
          type="password"
          name="password"
          autoComplete="current-password"
          placeholder="••••••••"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          icon={<Lock className="w-4 h-4" aria-hidden="true" />}
          disabled={isLoading}
        />

        <Button
          type="submit"
          variant="primary"
          size="md"
          className="w-full mt-2"
          isLoading={isLoading}
        >
          <span>Sign In to Account</span>
          <ArrowRight className="w-4 h-4 ml-2" aria-hidden="true" />
        </Button>
      </form>

      <div className="text-center pt-2 text-xs text-[#5B677A]">
        Do not have an account yet?{" "}
        <Link
          href="/sign-up"
          className="font-semibold text-[#8C6E43] hover:text-[#0F172A] underline"
        >
          Create an account
        </Link>
      </div>
    </div>
  );
}
