export function cn(
  ...classes: Array<string | false | null | undefined>
): string {
  return classes.filter(Boolean).join(" ");
}

export function formatPrice(
  amount: number,
  currency: string = "$",
  period: string = "mo"
): string {
  const formatted = new Intl.NumberFormat("en-US").format(amount);
  return `${currency}${formatted} / ${period}`;
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat("en-US").format(value);
}

export function squareFeetToSquareMeters(areaSqFt: number): number {
  return areaSqFt * 0.09290304;
}

export function squareMetersToSquareFeet(areaSqM: number): number {
  return areaSqM / 0.09290304;
}

export function formatAreaSqM(areaSqFt: number): string {
  return new Intl.NumberFormat("en-US", {
    maximumFractionDigits: 1,
  }).format(squareFeetToSquareMeters(areaSqFt));
}
